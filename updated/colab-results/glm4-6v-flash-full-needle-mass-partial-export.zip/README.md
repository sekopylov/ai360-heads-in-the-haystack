# GLM full-needle mass: recovered export

Original Drive files preserved without modification.
Detection: 27/27 cases. Masking: 649/660 saved JSON files.
Baseline/top5/top10/top15/top20: 110 each; top40: 99.
Missing top40: length 28474/depth100 and all ten depth positions at length30000.
The computation log reports these cases calculated, but they did not persist to Drive.
No fabricated results or completion flags were added. Context text files excluded.
See export_validation.json and download_inventory.json for validation and hashes.
